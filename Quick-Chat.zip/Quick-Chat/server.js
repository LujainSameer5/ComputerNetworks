var express = require('express');
var app     = express();
var server  = require('http').createServer(app);
var io      = require('socket.io')(server);
var fileUpload = require('express-fileupload');
var querystring = require('querystring');

//Add recent chats to messages array
var messages  = [];
var prevChats = 10;
var storeMessage = (name, data) =>{
  messages.push({name: name, data: data});
  if (messages.length > prevChats) {
    messages.shift();
  }
};

//Setup the app with Express
app.use(express.static(__dirname + '/frontend'));

//Setup file upload
app.use(fileUpload({createParentPath: true}));
app.post('/upload-file', async (req, res) => {
  try {
      if(!req.files) {
          res.send({
              status: false,
              message: 'No file uploaded'
          });
      } else {
          let fileupload = req.files.fileupload;
          fileupload.mv('./uploads/' + fileupload.name);
          res.send({
              status: true,
              message: 'File is uploaded',
              data: {
                  name: fileupload.name,
                  mimetype: fileupload.mimetype,
                  size: fileupload.size
              }
          });
      }
  } catch (err) {
      res.status(500).send(err);
  }
});
app.get("/GetFile", (req, res, next) => {
  res.sendFile(__dirname +'/uploads/'+req.query.name);
});

//Socket.io
io.on('connection', (socket) =>{

  //who has join
    socket.on('join', (name) =>{
    socket.userName = name;
    socket.broadcast.emit('chat', name + ' has joined the chat');
    console.log(name + ' has joined the chat');

  }); 

  //Log chats
  socket.on('chat', (message) =>{
    io.emit('chat', socket.userName + ': ' + message);
    storeMessage(socket.userName, message);
    console.log(socket.userName + ': ' + message);
  });

  //Log files uploaded
  socket.on('files', (message) =>{
    io.emit('files', socket.userName + ': ' + message);
    storeMessage(socket.userName, message);
    console.log(socket.userName + ': ' + message);
  });

});
//Listen at localhost:8000
server.listen(8000, () =>{
  console.log('The server is running on Port 8000');
});