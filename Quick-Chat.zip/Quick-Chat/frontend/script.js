(function($){
  $(function() {
    var socket = io();
    socket.on('connect', (data) => {
      var userName;
      do {
        userName = prompt('Please enter your user name');
        if (userName) {
          socket.emit('join', userName);
        }
      } while (!userName);
    });
    //Form submit
    $('form').submit(() => {
      socket.emit('chat', $('#message').val());
      $('#message').val('');
      return false;
    });

    //Display chats
    socket.on('chat', (message) => {
      $('#chat-body').append($('<li>').text(message));
      $('html, body').animate({
        scrollTop: $(document).height()
      });
    });

    //Display files
    socket.on('files', (message) => {
      $('#chat-body').append(message);
      $('html, body').animate({
        scrollTop: $(document).height()
      });
    });

    //Display users that join
    socket.on('join', (data) => {
      $('#chat-body').append($('<li>').text(data));
      $('html, body').animate({
        scrollTop: $(document).height()
      });
    });

    //submit a file
    $("#file_input").change(function(){
      var fd = new FormData();
      var files = $(this)[0].files;
      if(files.length > 0 ){
        fd.append('fileupload',files[0]);
        $.ajax({
            url: '/upload-file',
            type: 'post',
            data: fd,
            contentType: false,
            processData: false,
            success: function(response){
              if(response != 0){
                var html = "<li><a href='/getfile?name="+response.data.name+"' target='_blank'>"+response.data.name+"</a></li>";
                socket.emit('files', html);
              }else{
                  alert('file not uploaded');
              }
            },
            error:function(err){
              console.log(err)
            }
        });
      }else{
        alert("Please select a file.");
      }
    });
  });
})(jQuery);